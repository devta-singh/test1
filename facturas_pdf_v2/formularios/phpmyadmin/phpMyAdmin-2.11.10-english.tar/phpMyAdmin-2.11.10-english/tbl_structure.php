<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 *
 * @version $Id: tbl_structure.php 11354 2008-06-27 15:08:21Z lem9 $
 */

/**
 *
 */
require_once './libraries/common.inc.php';
require_once './libraries/mysql_charsets.lib.php';
require_once './libraries/relation.lib.php';

/**
 * Gets the relation settings
 */
$cfgRelation = PMA_getRelationsParam();


/**
 * Drop multiple fields if required
 */

// workaround for IE problem:
if (isset($submit_mult_change_x)) {
    $submit_mult = $strChange;
} elseif (isset($submit_mult_drop_x)) {
    $submit_mult = $strDrop;
} elseif (isset($submit_mult_primary_x)) {
    $submit_mult = $strPrimary;
} elseif (isset($submit_mult_index_x)) {
    $submit_mult = $strIndex;
} elseif (isset($submit_mult_unique_x)) {
    $submit_mult = $strUnique;
} elseif (isset($submit_mult_fulltext_x)) {
    $submit_mult = $strIdxFulltext;
}

if ((!empty($submit_mult) && isset($selected_fld))
    || isset($mult_btn)) {
    $action = 'tbl_structure.php';
    $err_url = 'tbl_structure.php?' . me containing wildcards
     */
    function _retrieve($like_db_name = '')
    {
        if ($this->_show_databases_disabled) {
            return array();
        }

        if (! empty($like_db_name)) {
            $like = " LIKE '" . $like_db_name . "';";
        } else {
            $like = ";";
        }

        $database_list = PMA_DBI_fetch_result('SHOW DATABASES' . $like, null, null, $this->_db_link);
        PMA_DBI_getError();

        if ($GLOBALS['errno'] !== 0) {
            // failed to get database list, try the control user
            // (hopefully there is one and he has SHOW DATABASES right)
            $this->_db_link = $this->_db_link_control;
            $database_list = PMA_DBI_fetch_result('SHOW DATABASES' . $like, null, null, $this->_db_link);

            PMA_DBI_getError();

            if ($GLOBALS['errno'] !== 0) {
                // failed! we will display a warning that phpMyAdmin could not safely
                // retrieve database list, the admin has to setup a control user or
                // allow SHOW DATABASES
                $GLOBALS['error_showdatabases'] = true;
                $this->_show_databases_disabled = true;
            }
        }

        return $database_list;
    }

    /**
     * builds up the list
     *
     * @uses    PMA_List_Database::$items to initialize it
     * @uses    PMA_List_Database::$_need_to_reindex
     * @uses    PMA_List_Database::_checkOnlyDatabase()
     * @uses    PMA_List_Database::_retrieve()
     * @uses    PMA_List_Database::_checkHideDatabase()
     * @uses    PMA_List_Database::_checkAccess()
     * @uses    PMA_MYSQL_INT_VERSION
     * @uses    array_values()
     * @uses    natsort()
     * @uses    $cfg['NaturalOrder']
     */
    function build()
    {
        $this->items = array();

        if (! $this->_checkOnlyDatabase()) {
            $this->items = $this->_retrieve();
            if ($GLOBALS['cfg']['NaturalOrder']) {
                natsort($this->items);
                $this->_need_to_reindex = true;
            }
        }

        $this->_checkHideDatabase();

        // Before MySQL 4.0.2, SHOW DATABASES could send the
        // whole list, so check if we really have access:
        if (PMA_MYSQL_INT_VERSION < 40002) {
            $this->_checkAccess();
        }

        if ($this->_need_to_reindex) {
            $this->items = array_values($this->items);
        }
    }

    /**
     * checks the only_db configuration
     *
     * @uses    PMA_List_Database::$_show_databases_disabled
     * @uses    PMA_List_Database::$items
     * @uses    PMA_List_Database::_retrieve()
     * @uses    PMA_unescape_mysql_wildcards()
     * @uses    preg_match()
     * @uses    array_diff()
     * @uses    array_merge()
     * @uses    is_array()
     * @uses    strlen()
     * @uses    is_string()
     * @uses    $cfg['Server']['only_db']
     * @return  boolean false if there is no only_db, otherwise true
     */
    function _checkOnlyDatabase()
    {
        if (is_string($GLOBALS['cfg']['Server']['only_db'])
         && strlen($GLOBALS['cfg']['Server']['only_db'])) {
            $GLOBALS['cfg']['Server']['only_db'] = array(
                $GLOBALS['cfg']['Server']['only_db']
            );
        }

        if (! is_array($GLOBALS['cfg']['Server']['only_db'])) {
            return false;
        }

        foreach ($GLOBALS['cfg']['Server']['only_db'] as $each_only_db) {
            if ($each_only_db === '*' && ! $this->_show_databases_disabled) {
                // append all not already listed dbs to the list
                $this->items = array_merge($this->items,
                    array_diff($this->_retrieve(), $this->items));
                // there can only be one '*', and this can only be last
                break;
            }

            // check if the db name contains wildcard,
            // thus containing not escaped _ or %
            if (! preg_match('/(^|[^\\\\])(_|%)/', $each_only_db)) {
                // ... not contains wildcard
                $this->items[] = PMA_unescape_mysql_wildcards($each_only_db);
                continue;
            }

            if (! $this->_show_databases_disabled) {
                $this->items = array_merge($this->items, $this->_retrieve($each_only_db));
                continue;
            }

            // @todo induce error, about not using wildcards with SHOW DATABASE disabled?
        }

        return true;
    }

    /**
     * returns default item
     *
     * @uses    PMA_List::getEmpty()
     * @uses    $GLOBALS['db']
     * @uses    strlen()
     * @return  string  default item
     */
    function getDefault()
    {
        if (strlen($GLOBALS['db'])) {
            return $GLOBALS['db'];
        }

        return $this->getEmpty();
    }

    /**
     * returns array with dbs grouped with extended infos
     *
     * @uses    $GLOBALS['PMA_List_Database']
     * @uses    $GLOBALS['cfgRelation']['commwork']
     * @uses    $cfg['ShowTooltip']
     * @uses    $cfg['LeftFrameDBTree']
     * @uses    $cfg['LeftFrameDBSeparator']
     * @uses    $cfg['ShowTooltipAliasDB']
     * @uses    PMA_getTableCount()
     * @uses    PMA_getComments()
     * @uses    is_array()
     * @uses    implode()
     * @uses    strstr()
     * @uses    explode()
     * @param   integer $offset
     * @param   integer $count
     * @return  array   db list
     */
    function getGroupedDetails($offset, $count)
    {
        $dbgroups   = array();
        $parts      = array();
        foreach ($this->getLimitedItems($offset, $count) as $key => $db) {
            // garvin: Get comments from PMA comments table
            $db_tooltip = '';
            if ($GLOBALS['cfg']['ShowTooltip']
              && $GLOBALS['cfgRelation']['commwork']) {
                $_db_tooltip = PMA_getComments($db);
                if (is_array($_db_tooltip)) {
                    $db_tooltip = implode(' ', $_db_tooltip);
                }
            }

            if ($GLOBALS['cfg']['LeftFrameDBTree']
                && $GLOBALS['cfg']['LeftFrameDBSeparator']
                && strstr($db, $GLOBALS['cfg']['LeftFrameDBSeparator']))
            {
                // use strpos instead of strrpos; it seems more common to
                // have the db name, the separator, then the rest which
                // might contain a separator
                // like dbname_the_rest
                $pos            = strpos($db, $GLOBALS['cfg']['LeftFrameDBSeparator']);
                $group          = substr($db, 0, $pos);
                $disp_name_cut  = substr($db, $pos);
            } else {
                $group          = $db;
                $disp_name_cut  = $db;
            }

            $disp_name  = $db;
            if ($db_tooltip && $GLOBALS['cfg']['ShowTooltipAliasDB']) {
                $disp_name      = $db_tooltip;
                $disp_name_cut  = $db_tooltip;
                $db_tooltip     = $db;
            }

            $dbgroups[$group][$db] = array(
                'name'          => $db,
                'disp_name_cut' => $disp_name_cut,
                'disp_name'     => $disp_name,
                'comment'       => $db_tooltip,
                'num_tables'    => PMA_getTableCount($db),
            );
        } // end foreach ($GLOBALS['PMA_List_Database']->items as $db)
        return $dbgroups;
    }

    /**
     * returns a part of the items 
     *
     * @uses    PMA_List_Database::$items
     * @uses    array_slice()
     * @param   integer $offset
     * @param   integer $count
     * @return  array  some items 
     */
    function getLimitedItems($offset, $count)
    {
        return(array_slice($this->items, $offset, $count));
    }

    /**
     * returns html code for list with dbs
     *
     * @return  string  html code list
     */
    function getHtmlListGrouped($selected = '', $offset, $count)
    {
        if (true === $selected) {
            $selected = $this->getDefault();
        }

        $return = '<ul id="databaseList" xml:lang="en" dir="ltr">' . "\n";
        foreach ($this->getGroupedDetails($offset, $count) as $group => $dbs) {
            if (count($dbs) > 1) {
                $return .= '<li>' . htmlspecialchars($group) . '<ul>' . "\n";
                // wether display db_name cuted by the group part
                $cut = true;
            } else {
                // .. or full
                $cut = false;
            }
            foreach ($dbs as $db) {
                $return .= '<li';
                if ($db['name'] == $selected) {
                    $return .= ' class="selected"';
                }
                $return .= '><a';
                if (! empty($db['comment'])) {
                    $return .= ' title="' . htmlspecialchars($db['comment']) . '"';
                }
                $return .= ' href="index.php?' . PMA_generate_common_url($db['name'])
                    . '" target="_parent">';
                if ($cut) {
                    $return .= htmlspecialchars($db['disp_name_cut']);
                } else {
                    $return .= htmlspecialchars($db['disp_name']);
                }
                $return .= ' (' . $db['num_tables'] . ')';
                $return .= '</a></li>' . "\n";
            }
            if (count($dbs) > 1) {
                $return .= '</ul></li>' . "\n";
            }
        }
        $return .= '</ul>';

        return $return;
    }

    /**
     * returns html code for select form element with dbs
     *
     * @todo IE can not handle different text directions in select boxes so,
     * as mostly names will be in english, we set the whole selectbox to LTR
     * and EN
     *
     * @return  string  html code select
     */
    function getHtmlSelectGrouped($selected = '', $offset, $count)
    {
        if (true === $selected) {
            $selected = $this->getDefault();
        }

        $return = '<select name="db" id="lightm_db" xml:lang="en" dir="ltr"'
            . ' onchange="if (this.value != \'\') window.parent.openDb(this.value);">' . "\n"
            . '<option value="" dir="' . $GLOBALS['text_dir'] . '">'
            . '(' . $GLOBALS['strDatabases'] . ') ...</option>' . "\n";
        foreach ($this->getGroupedDetails($offset, $count) as $group => $dbs) {
            if (count($dbs) > 1) {
                $return .= '<optgroup label="' . htmlspecialchars($group)
                    . '">' . "\n";
                // wether display db_name cuted by the group part
                $cut = true;
            } else {
                // .. or full
                $cut = false;
            }
            foreach ($dbs as $db) {
                $return .= '<option value="' . htmlspecialchars($db['name']) . '"'
                    .' title="' . htmlspecialchars($db['comment']) . '"';
                if ($db['name'] == $selected) {
                    $return .= ' selected="selected"';
                }
                $return .= '>' . htmlspecialchars($cut ? $db['disp_name_cut'] : $db['disp_name'])
                    .' (' . $db['num_tables'] . ')</option>' . "\n";
            }
            if (count($dbs) > 1) {
                $return .= '</optgroup>' . "\n";
            }
        }
        $return .= '</select>';

        return $return;
    }

    /**
     * this is just a backup, if all is fine this can be deleted later
     *
     * @deprecated
     * @access protected
     */
    function _checkAgainstPrivTables()
    {
        // 1. get allowed dbs from the "mysql.db" table
        // lem9: User can be blank (anonymous user)
        $local_query = "
            SELECT DISTINCT `Db` FROM `mysql`.`db`
            WHERE `Select_priv` = 'Y'
            AND `User`
            IN ('" . PMA_sqlAddslashes($GLOBALS['cfg']['Server']['user']) . "', '')";
        $tmp_mydbs = PMA_DBI_fetch_result($local_query, null, null,
            $GLOBALS['controllink']);
        if ($tmp_mydbs) {
            // Will use as associative array of the following 2 code
            // lines:
            //   the 1st is the only line intact from before
            //     correction,
            //   the 2nd replaces $dblist[] = $row['Db'];

            // Code following those 2 lines in correction continues
            // populating $dblist[], as previous code did. But it is
            // now populated with actual database names instead of
            // with regular expressions.
            var_dump($tmp_mydbs);
            $tmp_alldbs = PMA_DBI_query('SHOW DATABASES;', $GLOBALS['controllink']);
            // loic1: all databases cases - part 2
            if (isset($tmp_mydbs['%'])) {
                while ($tmp_row = PMA_DBI_fetch_row($tmp_alldbs)) {
                    $dblist[] = $tmp_row[0];
                } // end while
            } else {
                while ($tmp_row = PMA_DBI_fetch_row($tmp_alldbs)) {
                    $tmp_db = $tmp_row[0];
                    if (isset($tmp_mydbs[$tmp_db]) && $tmp_mydbs[$tmp_db] == 1) {
                        $dblist[]           = $tmp_db;
                        $tmp_mydbs[$tmp_db] = 0;
                    } elseif (!isset($dblist[$tmp_db])) {
                        foreach ($tmp_mydbs as $tmp_matchpattern => $tmp_value) {
                            // loic1: fixed bad regexp
                            // TODO: db names may contain characters
                            //       that are regexp instructions
                            $re        = '(^|(\\\\\\\\)+|[^\])';
                            $tmp_regex = ereg_replace($re . '%', '\\1.*', ereg_replace($re . '_', '\\1.{1}', $tmp_matchpattern));
                            // Fixed db name matching
                            // 2000-08-28 -- Benjamin Gandon
                            if (ereg('^' . $tmp_regex . '$', $tmp_db)) {
                                $dblist[] = $tmp_db;
                                break;
                            }
                        } // end while
                    } // end if ... elseif ...
                } // end while
            } // end else
            PMA_DBI_free_result($tmp_alldbs);
            unset($tmp_mydbs);
        } // end if

        // 2. get allowed dbs from the "mysql.tables_priv" table
        $local_query = 'SELECT DISTINCT Db FROM mysql.tables_priv WHERE Table_priv LIKE \'%Select%\' AND User = \'' . PMA_sqlAddslashes($GLOBALS['cfg']['Server']['user']) . '\'';
        $rs          = PMA_DBI_try_query($local_query, $GLOBALS['controllink']);
        if ($rs && @PMA_DBI_num_rows($rs)) {
            while ($row = PMA_DBI_fetch_assoc($rs)) {
                if (!in_array($row['Db'], $dblist)) {
                    $dblist[] = $row['Db'];
                }
            } // end while
            PMA_DBI_free_result($rs);
        } // end if
    }
}
?>
                      phpMyAdmin-2.11.10-english/libraries/ob.lib.php                                                     0000644 0000000 0000000 00000006511 11307234053 017702  0                                                                                                    ustar   root                            root                                                                                                                                                                                                                   <?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * Output buffer functions for phpMyAdmin
 *
 * Copyright 2001 Jeremy Brand <jeremy@nirvani.net>
 * http://www.jeremybrand.com/Jeremy/Brand/Jeremy_Brand.html
 *
 * Check for all the needed functions for output buffering
 * Make some wrappers for the top and bottoms of our files.
 *
 * @version $Id: ob.lib.php 10892 2007-11-01 20:48:43Z lem9 $
 */

/**
 * This function be used eventually to support more modes.  It is needed
 * because both header and footer functions must know what each other is
 * doing.
 *
 * @uses    $cfg['OBGzip']
 * @uses    function_exists()
 * @uses    ini_get()
 * @uses    ob_get_level()
 * @staticvar integer remember last calculated value
 * @return  integer  the output buffer mode
 */
function PMA_outBufferModeGet()
{
    static $mode = null;

    if (null !== $mode) {
        return $mode;
    }

    $mode = 0;

    if ($GLOBALS['cfg']['OBGzip'] && function_exists('ob_start')) {
        if (ini_get('output_handler') == 'ob_gzhandler') {
            // If a user sets the output_handler in php.ini to ob_gzhandler, then
            // any right frame file in phpMyAdmin will not be handled properly by
            // the browser. My fix was to check the ini file within the
            // PMA_outBufferModeGet() function.
            //
            // (Patch by Garth Gillespie, modified by Marc Delisle)
            $mode = 0;
        } elseif (function_exists('ob_get_level') && ob_get_level() > 0) {
            // If output buffering is enabled in php.ini it's not possible to
            // add the ob_gzhandler without a warning message from php 4.3.0.
            // Being better safe than sorry, check for any existing output handler
            // instead of just checking the 'output_buffering' setting.
            $mode = 0;
        } else {
            $mode = 1;
        }
    }

    // Zero (0) is no mode or in other words output buffering is OFF.
    // Follow 2^0, 2^1, 2^2, 2^3 type values for the modes.
    // Usefull if we ever decide to combine modes.  Then a bitmask field of
    // the sum of all modes will be the natural choice.

    return $mode;
} // end of the 'PMA_outBufferModeGet()' function


/**
 * This function will need to run at the top of all pages if output
 * output buffering is turned on.  It also needs to be passed $mode from
 * the PMA_outBufferModeGet() function or it will be useless.
 *
 * @uses    PMA_outBufferModeGet()
 * @uses    PMA_outBufferPost() to register it as shutdown function
 * @uses    ob_start()
 * @uses    header() to send X-ob_mode:
 * @uses    register_shutdown_function() to register PMA_outBufferPost()
 */
function PMA_outBufferPre()
{
    if ($mode = PMA_outBufferModeGet()) {
        ob_start('ob_gzhandler');
    }

    header('X-ob_mode: ' . $mode);

    register_shutdown_function('PMA_outBufferPost');
} // end of the 'PMA_outBufferPre()' function


/**
 * This function will need to run at the bottom of all pages if output
 * buffering is turned on.  It also needs to be passed $mode from the
 * PMA_outBufferModeGet() function or it will be useless.
 *
 * @uses    PMA_outBufferModeGet()
 * @uses    ob_flush()
 * @uses    flush()
 */
function PMA_outBufferPost()
{
    if (ob_get_status() && PMA_outBufferModeGet()) {
        ob_flush();
    } else {
        flush();
    }
} // end of the 'PMA_outBufferPost()' function

?>
                                                                                                                                                                                       phpMyAdmin-2.11.10-english/libraries/tbl_properties.inc.php                                         0000644 0000000 0000000 00000073225 11307234053 022350  0                                                                                                    ustar   root                            root                                                                                                                                                                                                                   <?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 *
 * @version $Id: tbl_properties.inc.php 11335 2008-06-21 14:01:54Z lem9 $
 */
if (! defined('PHPMYADMIN')) {
    exit;
}

/**
 * Check parameters
 */
require_once './libraries/common.inc.php';
PMA_checkParameters(array('db', 'table', 'action', 'num_fields'));


// Get available character sets and storage engines
require_once './libraries/mysql_charsets.lib.php';
require_once './libraries/StorageEngine.class.php';

if (is_int($cfg['DefaultPropDisplay'])) {
    if ($num_fields <= $cfg['DefaultPropDisplay']) {
        $display_type = 'vertical';
    } else {
        $display_type = 'horizontal';
    }
} else {
    $display_type = $cfg['DefaultPropDisplay'];
}

if ($cfg['CtrlArrowsMoving']) {
    ?>
<script src="./js/keyhandler.js" type="text/javascript"></script>
<script type="text/javascript">
// <![CDATA[
var switch_movement = <?php echo $display_type == 'horizontal' ? '0' : '1'; ?>;
document.onkeydown = onKeyDownArrowsHandler;
// ]]>
</script>
    <?php
}
// here, the div_x_7 represents a div id which contains
// the default CURRENT TIMESTAMP checkbox and label
// and, field_x_7a represents the checkbox itself

if (PMA_MYSQL_INT_VERSION >= 40102) {
    ?>
<script type="text/javascript">
// <![CDATA[
function display_field_options(field_type, i) {
    if (field_type == 'TIMESTAMP') {
        getElement('div_' + i + '_7').style.display = 'block';
    } else {
        getElement('div_' + i + '_7').style.display = 'none';
        getElement('field_' + i + '_7a').checked = false;
    }
    return true;
}
// ]]>
</script>
<?php } ?>

<form method="post" action="<?php echo $action; ?>">
<?php
echo PMA_generate_common_hidden_inputs($db, $table);
if ($action == 'tbl_create.php') {
    ?>
    <input type="hidden" name="reload" value="1" />
    <?php
} elseif ($action == 'tbl_addfield.php') {
    ?>
    <input type="hidden" name="field_where" value="<?php echo $field_where; ?>" />
    <input type="hidden" name="after_field" value="<?php echo PMA_sanitize($after_field); ?>" />
    <?php
}

if (isset($num_fields)) {
    ?>
    <input type="hidden" name="orig_num_fields" value="<?php echo $num_fields; ?>" />
    <?php
}

if (isset($field_where)) {
    ?>
    <input type="hidden" name="orig_field_where" value="<?php echo $field_where; ?>" />
    <?php
}

if (isset($after_field)) {
    ?>
    <input type="hidden" name="orig_after_field" value="<?php echo PMA_sanitize($after_field); ?>" />
    <?php
}

if (isset($selected) && is_array($selected)) {
    foreach ($selected AS $o_fld_nr => $o_fld_val) {
        ?>
    <input type="hidden" name="selected[<?php echo $o_fld_nr; ?>]" value="<?php echo urlencode($o_fld_val); ?>" />
        <?php
        if (!isset($true_selected)) {
            ?>
    <input type="hidden" name="true_selected[<?php echo $o_fld_nr; ?>]" value="<?php echo urlencode($o_fld_val); ?>" />
            <?php
        }

    }

    if (isset($true_selected) && is_array($true_selected)) {
        foreach ($true_selected AS $o_fld_nr => $o_fld_val) {
            ?>
        <input type="hidden" name="true_selected[<?php echo $o_fld_nr; ?>]" value="<?php echo urlencode($o_fld_val); ?>" />
            <?php
        }
    }

} elseif (isset($field)) {
    ?>
    <input type="hidden" name="orig_field" value="<?php echo urlencode($field); ?>" />
    <input type="hidden" name="true_selected[] value="<?php echo (isset($orig_field) ? $orig_field : urlencode($field)); ?>" />
    <?php
}

$is_backup = ($action != 'tbl_create.php' && $action != 'tbl_addfield.php');

$header_cells = array();
$content_cells = array();

$header_cells[] = $strField;
$header_cells[] = $strType . ($GLOBALS['cfg']['ReplaceHelpImg'] ? PMA_showMySQLDocu('SQL-Syntax', 'data-types') : '<br /><span style="font-weight: normal">' . PMA_showMySQLDocu('SQL-Syntax', 'data-types') . '</span>');
$header_cells[] = $strLengthSet . '<sup>1</sup>';
if (PMA_MYSQL_INT_VERSION >= 40100) {
    $header_cells[] = $strCollation;
}
$header_cells[] = $strAttr;
$header_cells[] = $strNull;
$header_cells[] = $strDefault . '<sup>2</sup>';
$header_cells[] = $strExtra;



// lem9: We could remove this 'if' and let the key information be shown and
// editable. However, for this to work, tbl_alter must be modified to use the
// key fields, as tbl_addfield does.

if (!$is_backup) {
    $header_cells[] = $cfg['PropertiesIconic'] ? '<img class="icon" src="' . $pmaThemeImage . 'b_primary.png" width="16" height="16" alt="' . $strPrimary . '" title="' . $strPrimary . '" />' : $strPrimary;
    $header_cells[] = $cfg['PropertiesIconic'] ? '<img class="icon" src="' . $pmaThemeImage . 'b_index.png" width="16" height="16" alt="' . $strIndex . '" title="' . $strIndex . '" />' : $strIndex;
    $header_cells[] = $cfg['PropertiesIconic'] ? '<img class="icon" src="' . $pmaThemeImage . 'b_unique.png" width="16" height="16" alt="' . $strUnique . '" title="' . $strUnique . '" />' : $strUnique;
    $header_cells[] = '---';
    $header_cells[] = $cfg['PropertiesIconic'] ? '<img class="icon" src="' . $pmaThemeImage . 'b_ftext.png" width="16" height="16" alt="' . $strIdxFulltext . '" title="' . $strIdxFulltext . '" />' : $strIdxFulltext;
}

require_once './libraries/relation.lib.php';
require_once './libraries/transformations.lib.php';
$cfgRelation = PMA_getRelationsParam();

$comments_map = array();
$mime_map = array();
$available_mime = array();

if ($cfgRelation['commwork'] || PMA_MYSQL_INT_VERSION >= 40100) {
    $comments_map = PMA_getComments($db, $table);
    $header_cells[] = $strComments;

    if ($cfgRelation['mimework'] && $cfg['BrowseMIME']) {
        $mime_map = PMA_getMIME($db, $table);
        $available_mime = PMA_getAvailableMIMEtypes();

        $header_cells[] = $strMIME_MIMEtype;
        $header_cells[] = $strMIME_transformation;
        $header_cells[] = $strMIME_transformation_options . '<sup>3</sup>';
    }
}

// garvin: workaround for field_fulltext, because its submitted indizes contain
//         the index as a value, not a key. Inserted here for easier maintaineance
//         and less code to change in existing files.
if (isset($field_fulltext) && is_array($field_fulltext)) {
    foreach ($field_fulltext AS $fulltext_nr => $fulltext_indexkey) {
        $submit_fulltext[$fulltext_indexkey] = $fulltext_indexkey;
    }
}

for ($i = 0 ; $i <= $num_fields; $i++) {
    $submit_null = FALSE;
    if (isset($regenerate) && $regenerate == TRUE) {
        // An error happened with previous inputs, so we will restore the data
        // to embed it once again in this form.

        $row['Field']     = (isset($field_name) && isset($field_name[$i]) ? $field_name[$i] : FALSE);
        $row['Type']      = (isset($field_type) && isset($field_type[$i]) ? $field_type[$i] : FALSE);
        if (PMA_MYSQL_INT_VERSION >= 40100) {
            $row['Collation']      = (isset($field_collation) && isset($field_collation[$i]) ? $field_collation[$i] : '');
        }
        $row['Null']      = (isset($field_null) && isset($field_null[$i]) ? $field_null[$i] : '');
        if (isset($field_type[$i]) && $row['Null'] == '') {
            $submit_null = TRUE;
        }

        if (isset(${'field_key_' . $i}) && ${'field_key_' . $i} == 'primary_' . $i) {
            $row['Key'] = 'PRI';
        } elseif (isset(${'field_key_' . $i}) && ${'field_key_' . $i} == 'index_' . $i) {
            $row['Key'] = 'MUL';
        } elseif (isset(${'field_key_' . $i}) && ${'field_key_' . $i} == 'unique_' . $i) {
            $row['Key'] = 'UNI';
        } else {
            $row['Key'] = '';
        }

        $row['Default']   = (isset($field_default) && isset($field_default[$i]) ? $field_default[$i] : FALSE);
        $row['Extra']     = (isset($field_extra) && isset($field_extra[$i]) ? $field_extra[$i] : FALSE);
        $row['Comment']   = (isset($submit_fulltext) && isset($submit_fulltext[$i]) && ($submit_fulltext[$i] == $i) ? 'FULLTEXT' : FALSE);

        $submit_length    = (isset($field_length) && isset($field_length[$i]) ? $field_length[$i] : FALSE);
        $submit_attribute = (isset($field_attribute) && isset($field_attribute[$i]) ? $field_attribute[$i] : FALSE);

        $submit_default_current_timestamp = (isset($field_default_current_timestamp) && isset($field_default_current_timestamp[$i]) ? TRUE : FALSE);

        if (isset($field_comments) && isset($field_comments[$i])) {
            $comments_map[$row['Field']] = $field_comments[$i];
        }

        if (isset($field_mimetype) && isset($field_mimetype[$i])) {
            $mime_map[$row['Field']]['mimetype'] = $field_mimetype[$i];
        }

        if (isset($field_transformation) && isset($field_transformation[$i])) {
            $mime_map[$row['Field']]['transformation'] = $field_transformation[$i];
        }

        if (isset($field_transformation_options) && isset($field_transformation_options[$i])) {
            $mime_map[$row['Field']]['transformation_options'] = $field_transformation_options[$i];
        }

    } elseif (isset($fields_meta) && isset($fields_meta[$i])) {
        $row = $fields_meta[$i];
    }

    if (isset($row) && isset($row['Type'])) {
        $type_and_length = PMA_extract_type_length($row['Type']);
        if ($type_and_length['type'] == 'bit') {
            $row['Default'] = PMA_printable_bit_value($row['Default'], $type_and_length['length']);
        }
    }

    // Cell index: If certain fields get left out, the counter shouldn't chage.
    $ci = 0;
    // Everytime a cell shall be left out the STRG-jumping feature, $ci_offset
    // has to be incremented ($ci_offset++)
    $ci_offset = -1;

    if ($is_backup) {
        $backup_field = (isset($true_selected) && isset($true_selected[$i]) && $true_selected[$i] ? $true_selected[$i] : (isset($row) && isset($row['Field']) ? urlencode($row['Field']) : ''));
        $content_cells[$i][$ci] = "\n" . '<input type="hidden" name="field_orig[]" value="' . $backup_field . '" />' . "\n";
    } else {
        $content_cells[$i][$ci] = '';
    }

    $content_cells[$i][$ci] .= "\n" . '<input id="field_' . $i . '_' . ($ci - $ci_offset) . '" type="text" name="field_name[]" size="10" maxlength="64" value="' . (isset($row) && isset($row['Field']) ? str_replace('"', '&quot;', $row['Field']) : '') . '" class="textfield" title="' . $strField . '" />';
    $ci++;
    $content_cells[$i][$ci] = '<select name="field_type[]" id="field_' . $i . '_' . ($ci - $ci_offset) . '" ';
    if (PMA_MYSQL_INT_VERSION >= 40102) {
        $content_cells[$i][$ci] .= 'onchange="display_field_options(this.options[this.selectedIndex].value,' . $i .')" ';
    }
    $content_cells[$i][$ci] .= '>' . "\n";

    if (empty($row['Type'])) {
        $row['Type'] = '';
        $type        = '';
    } else {
        $type        = $row['Type'];
    }
    // set or enum types: slashes single quotes inside options
    if (preg_match('@^(set|enum)\((.+)\)$@i', $type, $tmp)) {
        $type   = $tmp[1];
        $length = substr(preg_replace('@([^,])\'\'@', '\\1\\\'', ',' . $tmp[2]), 1);
    } else {
        // strip the "BINARY" attribute, except if we find "BINARY(" because
        // this would be a BINARY or VARBINARY field type
        $type   = preg_replace('@BINARY([^\(])@i', '', $type);
        $type   = preg_replace('@ZEROFILL@i', '', $type);
        $type   = preg_replace('@UNSIGNED@i', '', $type);

        $type_and_length = PMA_extract_type_length($type);
        $type = $type_and_length['type'];
        $length = $type_and_length['length'];
        unset($type_and_length);
    } // end if else

    // some types, for example longtext, are reported as
    // "longtext character set latin7" when their charset and / or collation
    // differs from the ones of the corresponding database.
    if (PMA_MYSQL_INT_VERSION >= 40100) {
        $tmp = strpos($type, 'character set');
        if ($tmp) {
            $type = substr($type, 0, $tmp-1);
        }
    }

    if (isset($submit_length) && $submit_length != FALSE) {
        $length = $submit_length;
    }

    // rtrim the type, for cases like "float unsigned"
    $type = rtrim($type);
    $type_upper = strtoupper($type);

    $cnt_column_types = count($cfg['ColumnTypes']);
    for ($j = 0; $j < $cnt_column_types; $j++) {
        $content_cells[$i][$ci] .= '                <option value="'. $cfg['ColumnTypes'][$j] . '"';
        if ($type_upper == strtoupper($cfg['ColumnTypes'][$j])) {
            $content_cells[$i][$ci] .= ' selected="selected"';
        }
        $content_cells[$i][$ci] .= '>' . $cfg['ColumnTypes'][$j] . '</option>' . "\n";
    } // end for

    $content_cells[$i][$ci] .= '    </select>';
    $ci++;

    if ($is_backup) {
        $content_cells[$i][$ci] = "\n" . '<input type="hidden" name="field_length_orig[]" value="' . urlencode($length) . '" />';
    } else {
        $content_cells[$i][$ci] = '';
    }

    if (preg_match('@^(set|enum)$@i', $type)) {
        $binary           = 0;
        $unsigned         = 0;
        $zerofill         = 0;
        $length_to_display = htmlspecialchars($length);
    } else {
        $length_to_display = $length;
        if (!preg_match('@BINARY[\(]@i', $row['Type']) && PMA_MYSQL_INT_VERSION < 40100) {
            $binary           = stristr($row['Type'], 'binary');
        } else {
            $binary           = FALSE;
        }
        $unsigned         = stristr($row['Type'], 'unsigned');
        $zerofill         = stristr($row['Type'], 'zerofill');
    }

    $content_cells[$i][$ci] .= "\n" . '<input id="field_' . $i . '_' . ($ci - $ci_offset) . '" type="text" name="field_length[]" size="8" value="' . str_replace('"', '&quot;', $length_to_display) . '" class="textfield" />' . "\n";
    $ci++;

    if (PMA_MYSQL_INT_VERSION >= 40100) {
        $tmp_collation          = empty($row['Collation']) ? null : $row['Collation'];
        $content_cells[$i][$ci] = PMA_generateCharsetDropdownBox(PMA_CSDROPDOWN_COLLATION, 'field_collation[]', 'field_' . $i . '_' . ($ci - $ci_offset), $tmp_collation, FALSE);
        unset($tmp_collation);
        $ci++;
    }

    $content_cells[$i][$ci] = '<select style="font-size: 70%;" name="field_attribute[]" id="field_' . $i . '_' . ($ci - $ci_offset) . '">' . "\n";

    $attribute  