<?php
$link = mysql_connect("localhost", "root", "");
mysql_select_db("lamp_t34", $link);

$sql = "select * from usuarios";
$cursor= mysql_query($sql, $link);
$numReg=mysql_num_rows($cursor);
print "actualmente hay $numReg registros<br/>";
print "<form action='eliminarDuplicados.php' method='post'>";
print "<input type='submit' value='Eliminar Duplicados'/>";
print "<input type='hidden' name='numRegAnt' value='".$numReg."' />";
print "</form>";
?>





