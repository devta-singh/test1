<?php
if(sizeof($_POST)!=0){
	$numRegAnt=$_POST["numRegAnt"];
	$link = mysql_connect("localhost", "root", "");
	mysql_select_db("lamp_t34", $link);
	
	$sql = "select * from usuarios";
	$cursor= mysql_query($sql, $link);
	$emails=array();
	$eliminados=array();
	while ($datos=mysql_fetch_assoc($cursor)){
		$id=$datos["id_usuario"];
		$email=$datos["email"];
		if(in_array($email, $emails)){
			mysql_query("DELETE FROM USUARIOS WHERE id_usuario=$id");
			$eliminados[]=$email;
			continue;
		}
		$emails[$id]=$email;
	}
	$numReg=sizeof($emails);
	$dif=$numRegAnt - $numReg;
	$fin=$numRegAnt-$dif;
	print "Se han borrado $dif registros:<br/>";
	print "<ol>";
	for($j=0;$j<sizeof($eliminados);$j+=1){
		print "<li>".$eliminados[$j]."</li>";
	}
	print "</ol>";
	print "Quedan $fin registros<br/>";
}else{
	print "No ha llegado nada";
}

?>